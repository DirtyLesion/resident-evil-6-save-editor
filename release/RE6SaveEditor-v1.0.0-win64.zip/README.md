# RE6 Save Editor

A small, dependency-free save editor for **Resident Evil 6 (PC / Steam)** `savedata.bin`, written in C++20 / Win32.

- Skill points, owned skills, and equipped skill loadouts (Campaign, Mercenaries, Siege, Onslaught, Survivors, Predator)
- Character and costume unlocks, Mercenaries stage unlocks (incl. No Mercy), Serpent Emblems
- Mercenaries records (solo and duo) and per-character inventory
- One-click **Unlock Everything**
- Checksum is recalculated automatically; a `.bak` backup is written before the first save

## Download

Grab `RE6SaveEditor-<version>-win64.zip` from the [Releases](../../releases) page, unzip, and run `RE6SaveEditor.exe`.
It's a single portable exe with no installer and no runtime dependencies (Windows 10 or later).

## Usage

1. **Close the game and disable Steam Cloud for RE6** (Steam → Library → RE6 → Properties → General),
   otherwise Steam may overwrite your edited save.
2. Make your own copy of your save as an extra backup. It lives at
   `Steam\userdata\<your-id>\221040\remote\savedata.bin`.
3. Open it with **Open…** (starts in that folder if Steam is found), or drag the file onto the window.
4. Pick a section on the left. Double-click a value (or press Enter / Space / F2) to edit it; Yes/No values toggle.
5. **Save**. The checksum is updated and the previous file is kept as `savedata.bin.bak`.

Notes:

- Only edit **your own** save. The save is tied to your profile ID, which the editor never changes.
- Steam achievements are stored by Steam, not in the save, so editing can't award them.

## Building from source

Requires Visual Studio 2022 or later with the **Desktop development with C++** workload.

```
build.bat                               # -> build\RE6SaveEditor.exe
build.bat test path\to\savedata.bin     # also runs the round-trip self-test on a copy of that save
```

Pushing a tag like `v1.0.0` makes the GitHub Actions workflow build the exe and attach it to a new Release.

## File format

The PC save is **not encrypted**; it's plaintext protected by a simple checksum. A file whose header doesn't match
(e.g. an encrypted console save) is rejected rather than edited.

| Offset | Type | Meaning |
|---|---|---|
| 0x00 | u32 | version/magic (`01 18 07 12`), untouched |
| 0x04 | u32 | file size |
| 0x08 | u32 | checksum: sum of all u32 words from 0x18 to EOF, mod 2^32 |
| 0x10 | u64 | profile ID |
| 0x20 | u32 × 6 | last-saved timestamp (Y, M, D, h, m, s) |
| 1812 + id | u8 | skill state per skill id: 0 = locked, 1 = available to buy, 3 = owned |

All other field offsets are in [src/fields.cpp](src/fields.cpp).

**Not verified in-game:** stage names for "Last stage", the Mercenaries rank encoding (0 = SS … 6 = E), and the
inventory header fields (not exposed). Serpent Emblems are written as `1` (what the game itself wrote in a test save);
some other tools write `3`. Several regions are not mapped yet (per-chapter campaign progress, titles/collectibles,
play statistics).

## Credits and disclaimer

Display names in [src/tables.h](src/tables.h) were taken from the labels in
[syntax-tm/RE6SaveEditor](https://github.com/syntax-tm/RE6SaveEditor); no code from that project is used.

Not affiliated with or endorsed by Capcom. Resident Evil is a trademark of Capcom Co., Ltd.
Use at your own risk and keep backups.
